class Person_record

  def initialize(last, first, gender, dob, fav_color)
    @last       = last
    @first      = first
    @gender     = gender
    @dob        = dob
    @fav_color  = fav_color
  end

  attr_accessor :last, :first, :gender, :dob, :fav_color

  def to_s
    "#{last}, #{first} #{gender} #{dob} #{fav_color}"
  end

end

class File_pillager

  def initialize
    @data = []
  end

  attr_accessor :data

  def comma_extract(comma_delimited_file)
    File.open(comma_delimited_file).each do |line|
      line.gsub!(",", "")
      array = line.split(' ')
      last      = array[0]
      first     = array[1]
      gender    = array[2]
      fav_color = array[3]
      dob       = array[4]
      new_person = Person_record.new(last, first, gender, dob, fav_color)
      @data.push(new_person)
    end
  end

  def pipe_extract(pipe_delimited_file)
    File.open(pipe_delimited_file).each do |line|
      line.gsub!("|", "")
      line.gsub!("-", "/")
      array = line.split(' ')
      last        = array[0]
      first       = array[1] + " " + array[2]
      fav_color   = array[4]
      dob         = array[5]
      if array[3] == 'M'
        gender = 'Male'
      else
        gender = 'Female'
      end
      new_person = Person_record.new(last, first, gender, dob, fav_color)
      @data.push(new_person)
    end
  end

  def space_extract(space_delimited_file)
    File.open(space_delimited_file).each do |line|
      line.gsub!("-", "/")
      array = line.split(' ')
      last      = array[0]
      first     = array[1] + " " + array[2]
      fav_color = array[5]
      dob       = array[4]
      if array[3] == 'M'
        gender = "Male"
      else
        gender = "Female"
      end
      new_person = Person_record.new(last, first, gender, dob, fav_color)
      @data.push(new_person)
    end
  end
end

class Data_sorter

  def initialize(obj_array)
    @data = obj_array
  end

  def sort_by_gender_then_last
    new_data = @data.sort_by { |a| [a.gender, a.last] }
  end

  def sort_by_dob
    new_data = @data.sort_by { |a| m,d,y=a.dob.split('/');[y,m,d] }
  end

  def sort_by_last_desc
    new_data = @data.sort { |a, b| b.last.downcase <=> a.last.downcase }
  end

end
