Thanks for reviewing my submission. This was written in Ruby version 2.1.1.

Here's how to get started, from the main folder:

To see displayed results:

  $ `ruby app.rb`

To run tests:

  $ `rspec spec`

To get in touch:

Ben Karl
benkarl@me.com
719-660-0519

Thank you!!
