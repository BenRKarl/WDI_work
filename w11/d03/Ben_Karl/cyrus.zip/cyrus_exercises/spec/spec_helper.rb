require_relative './../lib/extract_data.rb'

require 'yaml'
