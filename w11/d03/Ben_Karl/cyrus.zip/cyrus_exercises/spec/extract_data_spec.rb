require 'spec_helper'

describe Person_record do
  before :each do
    @bill = Person_record.new('Bill', 'James', 'Male', '2/4/1985', 'orange')
  end

  describe '#new' do
    it 'returns a new Person object' do
      expect(@bill).to be_an_instance_of Person_record
    end

    it 'returns a message with its to_s method' do
      actual = @bill.to_s
      expected = "Bill, James Male 2/4/1985 orange"
      expect(actual).to eq(expected)
    end
  end
end

describe File_pillager do
  before :each do
    @pillage = File_pillager.new
  end

  describe '#new' do
    it 'has a data attribute initially set to an empty array' do
      actual = @pillage.data
      expected = []
      expect(actual).to eq(expected)
    end
  end
end
