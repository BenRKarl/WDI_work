require_relative 'lib/extract_data'
comma = File.open('lib/comma_delimited.txt', 'r')
space = File.open('lib/space_delimited.txt', 'r')
pipe = File.open('lib/pipe_delimited.txt', 'r')

thing = File_pillager.new

thing.comma_extract(comma)
thing.pipe_extract(pipe)
thing.space_extract(space)

thingy = Data_sorter.new(thing.data)

puts 'Output 1:'
thingy.sort_by_gender_then_last.each do |person|
  puts person.to_s
end

puts " "

puts 'Output 2:'
thingy.sort_by_dob.each do |person|
  puts person.to_s
end

puts " "

puts 'Output 3:'
thingy.sort_by_last_desc.each do |person|
  puts person.to_s
end
