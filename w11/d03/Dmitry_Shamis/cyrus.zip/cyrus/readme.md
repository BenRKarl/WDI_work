Please access the files using the app.rb file

ruby app.rb
