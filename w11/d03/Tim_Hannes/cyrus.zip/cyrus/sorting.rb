def sort_by_sex(gender)

end

def sort_birth_date(date)

end

def sort_alphabetically(first_name, last_name)

end
