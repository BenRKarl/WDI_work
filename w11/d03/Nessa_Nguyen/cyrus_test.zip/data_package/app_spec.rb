require 'app'

describe '#sort_birthdate' do
  it 'sorts people by birthdate ascending' do

  end
end
