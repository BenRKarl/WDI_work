Test specs: http://www.cyrusinnovation.com/code-test-ruby/

### Instructions:
Cd into the folder and run `ruby app.rb`

### Version:
ruby 1.9.3p448
