Run script with "ruby app.rb" from the cyrus_code_test folder.
The script expects the files pipe_delimited.txt, comma_delimited.txt, and space_delimited.txt to be in the same folder.

Run the test with "ruby test_app.rb" from the cyrus_code_test/test folder.

Ruby version: ruby 2.1.1p76

Testing library: MiniTest